Development moved to https://gitlab.com/blacknet-ninja

https://persiantether.org/ aims to continue on PersianTether chain.
